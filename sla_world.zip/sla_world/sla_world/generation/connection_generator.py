from __future__ import annotations

from typing import Protocol

from sla_world.infrastructure.ids import IdSequence, ConnectionId
from sla_world.infrastructure.random import RandomSource
from sla_world.domain.galaxy import Galaxy
from sla_world.domain.system import StarSystem
from sla_world.domain.connection import Connection
from sla_world.config.generation import ConnectionConfig


class ConnectionStrategy(Protocol):
    def propose_pairs(
        self, galaxy: Galaxy, config: ConnectionConfig, rng: RandomSource
    ) -> list[tuple[StarSystem, StarSystem]]: ...


class DensityBasedConnectionStrategy:
    def propose_pairs(
        self, galaxy: Galaxy, config: ConnectionConfig, rng: RandomSource
    ) -> list[tuple[StarSystem, StarSystem]]:
        systems = galaxy.all_systems()
        pairs: list[tuple[StarSystem, StarSystem]] = []
        for index, system in enumerate(systems):
            for other in systems[index + 1:]:
                if galaxy.distance(system, other) > config.max_distance:
                    continue
                if rng.random() <= config.density:
                    pairs.append((system, other))
        return pairs


class ConnectionGenerator:
    def __init__(self, strategy: ConnectionStrategy | None = None) -> None:
        self._strategy = strategy or DensityBasedConnectionStrategy()

    def generate(
        self, galaxy: Galaxy, config: ConnectionConfig, id_sequence: IdSequence, rng: RandomSource
    ) -> list[Connection]:
        created: list[Connection] = []
        for system, other in self._strategy.propose_pairs(galaxy, config, rng):
            created.append(self._connect(galaxy, system, other, id_sequence))
        self._ensure_minimum_connections(galaxy, config, id_sequence)
        return created

    def _connect(self, galaxy: Galaxy, system: StarSystem, other: StarSystem, id_sequence: IdSequence) -> Connection:
        distance = galaxy.distance(system, other)
        connection = Connection(
            id=ConnectionId(id_sequence.next()),
            a=system.id,
            b=other.id,
            distance=distance,
            travel_cost=distance,
        )
        galaxy.add_connection(connection)
        return connection

    def _ensure_minimum_connections(self, galaxy: Galaxy, config: ConnectionConfig, id_sequence: IdSequence) -> None:
        for system in galaxy.all_systems():
            connected_ids = {galaxy.connections[cid].other(system.id) for cid in system.connection_ids}
            while len(system.connection_ids) < config.minimum_connections:
                candidates = [
                    other for other in galaxy.all_systems()
                    if other.id != system.id and other.id not in connected_ids
                ]
                if not candidates:
                    break
                target = min(candidates, key=lambda candidate: galaxy.distance(system, candidate))
                self._connect(galaxy, system, target, id_sequence)
                connected_ids.add(target.id)
